import java.util.Random;

public class Dragon extends Character{



    private int maxCharacterPoints = 20;
    private Random randomNum = new Random();


    public Dragon(){
        setMaxHealth(5);
        setCurrentHealth(5);
        setPoints(0);
    }

    public Dragon(String name, String className, int strength, int defense, int special){

        setMaxHealth(5);

        setName(name);
        setClassName(className);

        setCurrentHealth(5);

        setPoints(0);

        //checks to make sure the sum of the spec variables do not exceed 25, will change the variable to
        //1 or 0 depending on how many total points are left
        if(maxCharacterPoints-strength>0){
            setStrength(strength);
            maxCharacterPoints-=strength;
        }
        else{
            System.out.println("The sum of your specs cannot exceed 25! Your strength has been set to 1");
            setStrength(1);
            maxCharacterPoints-=1;
        }

        if(maxCharacterPoints-defense>=0){
            setDefense(defense);
            maxCharacterPoints-=defense;
        }
        else{
            if(maxCharacterPoints>0) {

                System.out.println("The sum of your specs cannot exceed 25! Your defense has been set to 1");
                setDefense(1);
                maxCharacterPoints -= 1;
            }
            else{
                System.out.println("The sum of our specs cannot exceed 25! Your defense has been set to 0");
                setDefense(0);
            }
        }

        if(maxCharacterPoints-special>=0){
            setSpecial(special);
            maxCharacterPoints-=special;
        }
        else{

            if(maxCharacterPoints>0) {
                System.out.println("The sum of your specs cannot exceed 25! Your special has been set to 1");
                setSpecial(1);
                maxCharacterPoints-=1;
            }
            else{
                System.out.println("The sum of your specs cannot exceed 25! Your special has been set to 0");
                setSpecial(0);
            }
        }


    }

    public double attack(){
        int[] op =getOppInfo();
        double damagePoints = randomNum.nextInt(getStrength());

        if(op[2]<getMyInfo()[2]){
            setPoints(getPoints()+5);
        }
        else{
            setPoints(getPoints()+1);
        }

        return damagePoints;
    }

    public double defend(){

        int[] op = getOppInfo();
        double damagePoints = randomNum.nextInt(getDefense());

        if(op[3]<getMyInfo()[3]){
            setPoints(getPoints()+5);
        }
        else{
            setPoints(getPoints()+1);
        }

        return damagePoints;
    }

    public void specialEffect(){

        Battle temp = new Battle();

        int defendIncrease = temp.rollDie(6);
        setPoints(getPoints()+4);
        if(defendIncrease>0) {

            setDefense(getDefense()+defendIncrease);

            System.out.println(getName()+ "'s defense increases by " + defendIncrease);
            System.out.println(getName() + " the dragon breathes fire on its opponent!");
        }

        else{
            System.out.println(getName()+ " tries to fly away from its opponent!");
        }
    }

    public String getCharacterType(){
        return "Dragon";
    }

}
