public interface TieBreaker {

    public int breakTie(Character c);

}