import java.util.Random;

public class Kirby extends Character{



    private int maxCharacterPoints = 20;
    private Random randomNum = new Random();

    public Kirby(){
        setMaxHealth(5);
        setCurrentHealth(5);
        setPoints(0);
    }

    public Kirby(String name, String className,int strength, int defense, int special){

        setMaxHealth(5);

        setName(name);
        setClassName(className);

        setCurrentHealth(5);

        setPoints(0);

        if(maxCharacterPoints-strength>0){
            setStrength(strength);
            maxCharacterPoints-=strength;
        }
        else{
            System.out.println("The sum of your specs cannot exceed 25! Your strength has been set to 1");
            setStrength(1);
            maxCharacterPoints-=1;
        }

        if(maxCharacterPoints-defense>=0){
            setDefense(defense);
            maxCharacterPoints-=defense;
        }
        else{
            if(maxCharacterPoints>0) {

                System.out.println("The sum of your specs cannot exceed 25! Your defense has been set to 1");
                setDefense(1);
                maxCharacterPoints -= 1;
            }
            else{
                System.out.println("The sum of our specs cannot exceed 25! Your defense has been set to 0");
                setDefense(0);
            }
        }

        if(maxCharacterPoints-special>=0){
            setSpecial(special);
            maxCharacterPoints-=special;
        }
        else{

            if(maxCharacterPoints>0) {
                System.out.println("The sum of your specs cannot exceed 25! Your special has been set to 1");
                setSpecial(1);
                maxCharacterPoints-=1;
            }
            else{
                System.out.println("The sum of your specs cannot exceed 25! Your special has been set to 0");
                setSpecial(0);
            }
        }


    }

    public double attack(){
        int[] op =getOppInfo();
        double damagePoints = randomNum.nextInt(getStrength());

        if(op[2]<getMyInfo()[2]){
            setPoints(getPoints()+5);
        }
        else{
            setPoints(getPoints()+1);
        }

        return damagePoints;
    }

    public double defend(){

        int[] op = getOppInfo();
        double damagePoints = randomNum.nextInt(getDefense());

        if(op[3]<getMyInfo()[3]){
            setPoints(getPoints()+5);
        }
        else{
            setPoints(getPoints()+1);
        }

        return damagePoints;
    }

    public void specialEffect(){

        //increase strength and defense by the value of special

        setPoints(getPoints()+4);
        setStrength(getStrength() + getSpecial());
        setDefense(getDefense() + getSpecial());

        System.out.println(getName()+"'s kirby has its strength and defense increased by the " +
                "the value of its special");

    }


}
